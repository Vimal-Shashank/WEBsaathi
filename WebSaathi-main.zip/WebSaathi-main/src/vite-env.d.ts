
/// <reference types="vite/client" />

// Add deviceMemory property to the Navigator interface
interface Navigator {
  deviceMemory?: number;
}
